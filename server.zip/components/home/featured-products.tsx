"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Check, ArrowLeft, Package, Car } from "lucide-react";
import { SafeImage } from "@/components/ui/safe-image";
import { useProductStore } from "@/store/product-store";
import { useVehicleStore } from "@/store/vehicle-store";
import { useAdminStore } from "@/store/admin-store";
import { VehicleLogo } from "@/components/ui/vehicle-logo";
import { useProducts } from "@/services/products";
import { getPlaceholderImage } from "@/lib/image-utils";
import type { Product } from "@/types/product";

export function FeaturedProducts() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [isHydrated, setIsHydrated] = useState(false);
  const getEnabledProducts = useProductStore((state) => state.getEnabledProducts);
  const { settings, updateSettings } = useAdminStore();
  // Use itemsPerPage from settings directly (respect user's setting)
  const featuredCount = settings.itemsPerPage || 10;
  
  // #region agent log
  if (typeof window !== "undefined") {
    fetch('http://127.0.0.1:7242/ingest/6e2493c0-cc8b-4c0b-9456-c04638b7e615',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'featured-products.tsx:25',message:'FeaturedProducts: featuredCount calculated',data:{itemsPerPage:settings.itemsPerPage,featuredCount,settingsKeys:Object.keys(settings)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'P'})}).catch(()=>{});
  }
  // #endregion
  
  const { data: apiProducts, isLoading } = useProducts(undefined, 1, featuredCount);
  const addProduct = useProductStore((state) => state.addProduct);
  const { vehicles, getVehicle, loadVehiclesFromDB } = useVehicleStore();

  // Load settings from API on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const response = await fetch("/api/site-settings");
        if (response.ok) {
          const result = await response.json();
          if (result.success && result.data) {
            // Pass saveToAPI=false to prevent PUT request when loading settings
            updateSettings(result.data, false);
          }
        }
      } catch (error) {
        console.error("Error loading settings:", error);
      }
    };
    loadSettings();
    
    // Listen for settings updates
    const handleSettingsUpdate = () => {
      loadSettings();
    };
    
    window.addEventListener("settingsUpdated", handleSettingsUpdate);
    
    return () => {
      window.removeEventListener("settingsUpdated", handleSettingsUpdate);
    };
  }, [updateSettings]);

  // Load vehicles on mount
  useEffect(() => {
    if (vehicles.length === 0) {
      loadVehiclesFromDB().catch(console.error);
    }
  }, [vehicles.length, loadVehiclesFromDB]);

  // Sync API products to store
  useEffect(() => {
    if (apiProducts && apiProducts.length > 0) {
      apiProducts.forEach((product: Product) => {
        const existing = useProductStore.getState().getProduct(product.id);
        if (!existing) {
          addProduct(product);
        }
      });
    }
  }, [apiProducts, addProduct]);

  // Use API products if available, otherwise fallback to store
  useEffect(() => {
    setIsHydrated(true);
    // #region agent log
    if (typeof window !== "undefined") {
      fetch('http://127.0.0.1:7242/ingest/6e2493c0-cc8b-4c0b-9456-c04638b7e615',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'featured-products.tsx:68',message:'FeaturedProducts: Updating featured products',data:{apiProductsLength:apiProducts?.length||0,featuredCount,isLoading,willSliceTo:Math.min(apiProducts?.length||0,featuredCount)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'Q'})}).catch(()=>{});
    }
    // #endregion
    if (apiProducts && apiProducts.length > 0) {
      setFeaturedProducts(apiProducts.slice(0, featuredCount));
    } else if (!isLoading) {
      // Only use store if API is not loading
      const products = getEnabledProducts().slice(0, featuredCount);
      setFeaturedProducts(products);
    }
  }, [apiProducts, isLoading, getEnabledProducts, featuredCount]);

  return (
    <section className="py-8 sm:py-12 md:py-16 lg:py-20 relative overflow-hidden">

      <div className="container px-4 sm:px-4 relative z-10">
        {/* Minimal Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-6 sm:mb-8 md:mb-12 lg:mb-16"
        >
          {/* Badge - Hidden on mobile */}
          <div className="glass-morphism-light hidden sm:inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full mb-3 sm:mb-4">
            <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-accent" />
            <span className="text-xs sm:text-sm font-medium text-accent">محصولات ویژه</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold sm:font-extrabold mb-2 sm:mb-3 md:mb-4 text-foreground">
            محصولات <span className="text-primary sm:text-accent">پرفروش</span>
          </h2>
          <p className="hidden sm:block text-muted-foreground text-sm sm:text-base md:text-lg lg:text-xl px-2 max-w-2xl mx-auto">
            بهترین و پرفروش‌ترین قطعات خودرو با کیفیت تضمینی
          </p>
        </motion.div>

        {/* Minimal Grid - Clean on mobile */}
        {(!isHydrated || isLoading) ? (
          // Show loading skeleton during hydration to match server render
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-2 sm:gap-3 md:gap-4" suppressHydrationWarning>
            {Array.from({ length: featuredCount }).map((_, index) => (
              <div key={index} className="animate-pulse">
                <Card className="h-full flex flex-col border-[0.1px] border-border/2">
                  <CardHeader className="p-0">
                    <div className="relative h-20 sm:h-24 md:h-28 w-full bg-muted rounded-t-lg" />
                  </CardHeader>
                  <CardContent className="p-1.5 sm:p-2">
                    <div className="h-3 bg-muted rounded mb-2" />
                    <div className="h-2 bg-muted rounded w-2/3" />
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        ) : featuredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 sm:py-16 md:py-20">
            <Package className="h-12 w-12 sm:h-16 sm:w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg sm:text-xl font-semibold mb-2">محصولی یافت نشد</h3>
            <p className="text-sm sm:text-base text-muted-foreground text-center">
              در حال حاضر محصولی برای نمایش وجود ندارد
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-2 sm:gap-3 md:gap-4">
            {featuredProducts.map((product, index) => {
              const discount = product.originalPrice && product.originalPrice > product.price
                ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
                : 0;
            
            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: index * 0.08,
                  duration: 0.4,
                  type: "spring",
                  stiffness: 120
                }}
                whileHover={{ y: -4, scale: 1.01 }}
                className="group"
              >
                <Link href={`/products/${product.id}`}>
                  <Card className="glass-morphism h-full flex flex-col relative overflow-hidden transition-all duration-300 hover:shadow-2xl group-hover:scale-105 cursor-pointer">
                    {/* Shine Effect - Only on desktop */}
                    <div className="hidden sm:block absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/5 to-transparent z-10" />
                    
                    <CardHeader className="p-0 relative">
                      <div className="relative h-20 sm:h-24 md:h-28 w-full bg-gradient-to-br from-primary/10 sm:from-primary/20 to-primary/5 sm:to-primary/10 rounded-t-lg sm:rounded-t-xl overflow-hidden">
                        <SafeImage
                          src={Array.isArray(product.images) && product.images.length > 0 ? product.images[0] : null}
                          alt={`${product.name}${product.brand ? ` - برند ${product.brand}` : ''} - محصول پرفروش`}
                          fill
                          className="w-full h-full group-hover:scale-105 sm:group-hover:scale-110 transition-transform duration-500"
                          loading="eager"
                          priority={index < 6}
                          sizes="(max-width: 640px) 33vw, (max-width: 768px) 25vw, (max-width: 1024px) 20vw, (max-width: 1280px) 16vw, 14vw"
                          productId={product.id}
                        />
                        
                        {/* Discount Badge - Smaller on mobile */}
                        {product.originalPrice && product.originalPrice > product.price && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute top-0.5 right-0.5 sm:top-1 sm:right-1 bg-red-500 text-white text-[8px] sm:text-[9px] font-bold px-1 sm:px-1.5 py-0.5 rounded shadow-sm z-20"
                          >
                            {discount}%
                          </motion.div>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="flex-1 p-1.5 sm:p-2 relative z-10">
                      <h3 className="font-medium mb-0.5 sm:mb-1 hover:text-primary transition-colors line-clamp-2 text-[10px] sm:text-xs leading-tight text-foreground group-hover:text-primary">
                        {product.name}
                      </h3>
                      
                      {/* Vehicle Info */}
                      {product.vehicle && (() => {
                        const vehicle = getVehicle(product.vehicle);
                        if (!vehicle) return null;
                        return (
                          <div className="flex items-center gap-1 mb-0.5 sm:mb-1 text-[8px] sm:text-[9px] text-muted-foreground line-clamp-1">
                            <VehicleLogo
                              logo={vehicle.logo}
                              alt={vehicle.name}
                              size="sm"
                              fallbackIcon={false}
                              className="flex-shrink-0"
                            />
                            <span className="font-medium truncate">{vehicle.name}</span>
                            {product.model && (
                              <>
                                <span className="text-[7px]">•</span>
                                <span className="truncate">{product.model}</span>
                              </>
                            )}
                          </div>
                        );
                      })()}
                      
                      {/* Price - Minimal on mobile */}
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[10px] sm:text-xs font-bold text-primary">
                          {product.price.toLocaleString("fa-IR")} <span className="text-[8px] sm:text-[9px]">تومان</span>
                        </span>
                        {product.originalPrice && product.originalPrice > product.price && (
                          <span className="text-[8px] sm:text-[9px] text-muted-foreground line-through">
                            {product.originalPrice.toLocaleString("fa-IR")}
                          </span>
                        )}
                      </div>
                    </CardContent>
                    
                    {/* Hover Border Effect - Only on desktop */}
                    <div className="hidden sm:block absolute inset-0 border-[0.1px] border-primary/0 group-hover:border-primary/15 rounded-lg transition-all duration-300 pointer-events-none" />
                  </Card>
                </Link>
              </motion.div>
            );
          })}
          </div>
        )}

        {/* View All Button - Minimal on mobile */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="text-center mt-6 sm:mt-8 md:mt-12 lg:mt-16"
        >
          <Link href="/products">
            <Button 
              size="lg" 
              variant="outline" 
              className="glass-morphism-light h-10 sm:h-12 md:h-14 px-6 sm:px-8 md:px-10 text-sm sm:text-base md:text-lg rounded-lg sm:rounded-xl text-foreground hover:bg-foreground/10 sm:hover:bg-foreground/20 transition-all active:scale-95 sm:hover:scale-105 group"
            >
              <span className="hidden sm:inline">مشاهده همه محصولات</span>
              <span className="sm:hidden">همه محصولات</span>
              <ArrowLeft className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 mr-1.5 sm:mr-2 group-hover:translate-x-1 transition-transform hidden sm:inline" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

