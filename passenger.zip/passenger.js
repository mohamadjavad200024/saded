// Phusion Passenger entry point for Next.js
// این فایل برای Passenger استفاده می‌شود

// CRITICAL: Disable Turbopack BEFORE loading Next.js
process.env.NEXT_PRIVATE_SKIP_TURBO = '1';
delete process.env.NEXT_PRIVATE_TURBO;
delete process.env.TURBOPACK;
process.env.NEXT_PRIVATE_WEBPACK = '1';

// Load environment variables
try {
  if (process.env.NODE_ENV === 'production') {
    require('dotenv').config({ path: '.env.production' });
    try { require('dotenv').config({ path: '.env' }); } catch (e) {}
  } else {
    require('dotenv').config({ path: '.env.local' });
  }
  process.env.NEXT_PRIVATE_SKIP_TURBO = '1';
  process.env.NEXT_PRIVATE_WEBPACK = '1';
} catch (e) {
  console.log('Note: .env file not found, using environment variables from system');
}

const next = require('next');
const fs = require('fs');
const path = require('path');
const { parse } = require('url');

const buildIdPath = path.join(__dirname, '.next', 'BUILD_ID');
const hasBuild = fs.existsSync(buildIdPath);
const nodeEnv = hasBuild ? (process.env.NODE_ENV || 'production') : 'development';
const dev = !hasBuild || nodeEnv === 'development';

console.log('='.repeat(50));
console.log('Initializing Next.js for Passenger');
console.log('='.repeat(50));
console.log('Build exists:', hasBuild);
console.log('NODE_ENV:', nodeEnv);
console.log('Dev mode:', dev);

const app = next({ 
  dev: dev,
  hostname: process.env.HOSTNAME || '0.0.0.0',
  port: parseInt(process.env.PORT || process.env.PASSENGER_PORT || '3000', 10),
  ...(dev ? { turbo: false } : {})
});

const handle = app.getRequestHandler();

// Prepare the app synchronously if possible, or export a promise
// Passenger can handle both function and promise exports
let appReady = false;

const prepareApp = app.prepare().then(() => {
  appReady = true;
  console.log('Next.js app prepared successfully for Passenger');
  return true;
}).catch((err) => {
  console.error('Failed to prepare Next.js app:', err);
  console.error('Error stack:', err.stack);
  process.exit(1);
});

// Export the request handler
// Passenger will call this function for each HTTP request
module.exports = function(req, res) {
  // If app is not ready yet, wait for it
  if (!appReady) {
    prepareApp.then(() => {
      const parsedUrl = parse(req.url, true);
      return handle(req, res, parsedUrl);
    }).catch((err) => {
      console.error('Error in request handler:', err);
      if (!res.headersSent) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'text/plain');
        res.end('Internal Server Error: Application is starting up');
      }
    });
    return;
  }
  
  try {
    const parsedUrl = parse(req.url, true);
    return handle(req, res, parsedUrl);
  } catch (err) {
    console.error('Error handling request:', err);
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader('Content-Type', 'text/plain');
      res.end('Internal Server Error');
    }
  }
};
